# Mongodb-Grafana-Plugin

Mongodb local data source
